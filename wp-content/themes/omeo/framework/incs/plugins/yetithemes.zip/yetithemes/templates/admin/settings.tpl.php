<?php
/**
 * Package: yesshop.
 * User: kinhdon
 * Date: 1/31/2016
 * Vertion: 1.0
 */

?>

<div class="wrap about-wrap yetithemes-wrap">

    <?php do_action('yetithemes_plugin_panel_header'); ?>

    <div class="nav-tab-conent">
        <div class="col-2">
            <section class="yeti-section">content 1</section>
        </div>
        <div class="col-2 last">
            <section class="yeti-section">content 1</section>
        </div>
        <div class="col-2">
            <section class="yeti-section">content 1</section>
        </div>

    </div>

</div>
